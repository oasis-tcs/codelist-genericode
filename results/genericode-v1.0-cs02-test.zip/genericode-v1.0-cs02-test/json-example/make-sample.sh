saxon9he -xsl:../xslt/gc2gcj.xsl -s:../xml/CaseTypeCode.gc -o:CaseTypeCode.gcj
saxon9he -xsl:../xslt/gc2gcj.xsl -s:../xml/ChannelCode-2.3.gc -o:ChannelCode-2.3.gcj
saxon9he -xsl:../xslt/gc2gcj.xsl -s:../xml/CurrencyCode-2.3.gc -o:CurrencyCode-2.3.gcj
saxon9he -xsl:../xslt/gc2gcj.xsl -s:../xml/UnitOfMeasureCode-2.3.gc -o:UnitOfMeasureCode-2.3.gcj
